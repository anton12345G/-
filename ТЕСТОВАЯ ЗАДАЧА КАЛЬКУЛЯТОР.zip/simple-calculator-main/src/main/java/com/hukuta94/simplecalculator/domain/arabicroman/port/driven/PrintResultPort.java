package com.hukuta94.simplecalculator.domain.arabicroman.port.driven;

public interface PrintResultPort
{
    void print( String result );
}
