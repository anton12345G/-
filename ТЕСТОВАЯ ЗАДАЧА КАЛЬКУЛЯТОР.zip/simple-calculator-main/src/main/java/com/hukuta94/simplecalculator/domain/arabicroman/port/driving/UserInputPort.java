package com.hukuta94.simplecalculator.domain.arabicroman.port.driving;

public interface UserInputPort
{
    String getResult( String inputLine );
}
