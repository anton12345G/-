package com.hukuta94.simplecalculator.presenter.javafx.view;

public class Main {
}
