package com.hukuta94.simplecalculator.domain.arabicroman.model;

public enum NumberType
{
    ROMAN,
    ARABIC
}
