package com.hukuta94.simplecalculator.application;

public class Main
{
    public static void main( String[] args )
    {
        JavaFXAppLauncher.main( args );
    }
}
