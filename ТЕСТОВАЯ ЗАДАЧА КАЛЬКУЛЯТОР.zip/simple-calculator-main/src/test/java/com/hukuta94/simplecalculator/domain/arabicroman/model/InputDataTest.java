package com.hukuta94.simplecalculator.domain.arabicroman.model;

public class InputDataTest {
}
